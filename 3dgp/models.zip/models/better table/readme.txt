This object is identical to the original table.obj apart from that:

render(0, m) renders the chair frame only
render(1, m) renders the chair cushions
render(2, m) renders the table

This will facilitate texturing the chair frame and the cushions separately.
Credits: Daniel Raczynski (student in the 2023/24 year group)
